import random as r
archivos=["LaLojanita.txt","PezAzul.txt","LosArbolitos.txt"]

'''
Cree la funcion leerProductos() que retorne una lista de los productos, una lista de precios y una lista con los productos que tienen descuento
en esta semana. 
'''

'''
Cree la funcion leerPedidosRestaurantes(archivos, productos) que recibe la lista de archivos y la lista de productos. 
retorna una matriz cuyas filas son los restaurantes y columnas 
son los productos, los valores es la cantidad en libras que ha pedido cada restaurante del producto dado
Considere hacer una matriz de ceros.
'''


'''
Cree la funcion crearFactura(matriz, productos, precios, pDescuentos, archivos) que genere un archivo de factura en el siguiente formato
facturaRestaurante.txt ej-> facturaLaLojanita.txt
La factura debe contener el producto, la cantidad el precio y si tuvo descuento o no. Ejemplo:

producto, cantidad, precio, descuento
yuca,5,4.78, 0

'''